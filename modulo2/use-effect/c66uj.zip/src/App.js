import React from "react";
import axios from "axios";
import { useState, useEffect } from "react";
import PokeCard from "./components/PokeCard/PokeCard";

export default function App() {
  const [pokeList, setPokeList] = useState("");
  const [pokeName, setPokeName] = useState("");

  useEffect(() => {
    axios
      .get("https://pokeapi.co/api/v2/pokemon/?limit=151")
      .then((res) => {
        console.log(res.data);
        // setPokeList(res.data.results);
        setPokeName(res.data.name);
      })
      .catch((error) => {
        console.log(error.response.data);
      });
  }, []);

  changePokeName = (event) => {
    setPokeName(event.target.value);
    console.log(event.target.value);
  };

  return (
    <div>
      <h1>PokeDex - Carveniana!</h1>

      <select onChange={changePokeName}>
        <option value={pokeList}>Nenhum</option>
        {/* 
        {pokeList.map((pokemon) => {
          return (
            <option key={pokemon.name} value={pokemon.name}>
              {pokemon.name}
            </option> */}
        ); })}
      </select>

      {pokeName && <PokeCard pokemon={pokeName} />}
    </div>
  );
}
